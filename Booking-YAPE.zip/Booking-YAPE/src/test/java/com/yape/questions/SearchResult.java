package com.yape.questions;

import com.yape.userinterfaces.SearchScreen;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class SearchResult {

    public static Question<String> resultText(){
        return actor -> Text.of(SearchScreen.RESULT_TEXT).answeredBy(actor);
    }
}
